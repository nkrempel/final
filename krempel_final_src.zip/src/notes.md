Notes for NewsMe project

Actions
fetchArticles
loadArticles
fetchCategories
saveSelectedSources
retrieveSources
fetchSourceArticles


Routes
/
/categories
/feed

page title and Nav are on all pages

State
news
subscribedSources


Categories page presents atleast three new categories from which the user can subscribe to individual sources per category
