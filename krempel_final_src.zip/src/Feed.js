import React, { Component } from 'react';
import './App.css';
import './ui-toolkit/css/nm-cx/main.css' /* Need to copy this */


//retrieve the saved sources via componentDidMount
//fetch articles from those sources via dispatch call
//display retrieved articles similar to other display sections
class Feed extends Component {
    render() {
        return (
            <div>

            </div>
        );
    }
}

export default Feed;